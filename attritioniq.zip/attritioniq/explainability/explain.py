"""
AttritionIQ — SHAP Explainability
Generates SHAP values and top reason codes per employee.
Makes model output interpretable for non-technical People leaders.
"""

import shap
import joblib
import pandas as pd
import numpy as np
import logging
from pathlib import Path

log = logging.getLogger(__name__)
MODEL_PATH = Path("models/attrition_model.pkl")


def load_model():
    artifact = joblib.load(MODEL_PATH)
    return artifact["model"], artifact["feature_cols"]


def compute_shap_values(model, X: pd.DataFrame) -> np.ndarray:
    """Compute SHAP values using TreeExplainer (fast for XGBoost)."""
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    log.info(f"Computed SHAP values for {len(X):,} employees")
    return shap_values, explainer.expected_value


def top_reason_codes(shap_values: np.ndarray, feature_cols: list,
                     n_reasons: int = 3) -> pd.DataFrame:
    """
    For each employee, return the top N features driving their risk score.
    Output is suitable for Tableau tooltip and People leader dashboards.
    """
    rows = []
    for i, sv in enumerate(shap_values):
        ranked = sorted(zip(feature_cols, sv), key=lambda x: abs(x[1]), reverse=True)
        for rank, (feat, val) in enumerate(ranked[:n_reasons], 1):
            rows.append({
                "employee_idx":  i,
                "reason_rank":   rank,
                "feature":       feat,
                "shap_value":    round(val, 4),
                "direction":     "increases risk" if val > 0 else "decreases risk"
            })
    return pd.DataFrame(rows)


def score_and_explain(df_scored: pd.DataFrame, feature_cols: list) -> pd.DataFrame:
    """
    Attach risk_score, risk_tier, and top reason codes to a scored DataFrame.
    """
    model, _ = load_model()
    X = df_scored[feature_cols]

    risk_scores = model.predict_proba(X)[:, 1]
    df_scored = df_scored.copy()
    df_scored["attrition_risk_score"] = risk_scores.round(4)
    df_scored["risk_tier"] = pd.cut(
        risk_scores,
        bins=[0, 0.3, 0.6, 1.01],
        labels=["Low", "Medium", "High"]
    )

    shap_values, base_value = compute_shap_values(model, X)
    reason_df = top_reason_codes(shap_values, feature_cols)
    reason_df["employee_idx"] = reason_df["employee_idx"].map(
        dict(enumerate(df_scored.index))
    )

    log.info("Risk tier distribution:")
    log.info(df_scored["risk_tier"].value_counts().to_string())

    return df_scored, reason_df


if __name__ == "__main__":
    import sys
    from features import load_hr_data, build_features, split_features_target

    data_path = sys.argv[1] if len(sys.argv) > 1 else "data/hr_data.csv"
    df_raw = load_hr_data(data_path)
    df, feature_cols = build_features(df_raw)
    X, _ = split_features_target(df, feature_cols)

    model, _ = load_model()
    df_out, reasons = score_and_explain(df, feature_cols)

    df_out[["employee_id", "attrition_risk_score", "risk_tier"]].to_csv(
        "data/scored_employees.csv", index=False
    )
    reasons.to_csv("data/reason_codes.csv", index=False)
    log.info("Output written to data/scored_employees.csv and data/reason_codes.csv")
