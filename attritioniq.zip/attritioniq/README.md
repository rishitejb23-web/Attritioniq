# AttritionIQ — Employee Attrition Prediction and Retention Risk Scoring

Predicts 90-day voluntary attrition risk per employee using XGBoost. Features SHAP-based explainability for non-technical People leaders, weekly Airflow-scheduled retraining, and a Tableau reporting model with department-level risk heatmaps.

## Architecture

```
HR Data (Workday HCM / CSV)
        │
        ▼
  Feature Engineering
  (features.py)
        │
        ▼
  XGBoost Classifier
  (train.py)
        │
        ▼
  SHAP Explainability
  (explain.py)
        │
        ▼
  Scored Output → Tableau
```

## Stack
- **Python** — feature engineering, model training, SHAP
- **XGBoost** — gradient boosted classifier (AUC 0.84)
- **SHAP** — model explainability, feature-level reason codes
- **scikit-learn** — preprocessing, evaluation metrics
- **pandas / NumPy** — data manipulation
- **SQL / PostgreSQL** — scored output storage
- **Airflow** — weekly retraining DAG
- **Tableau** — risk heatmap dashboard

## Quickstart

```bash
pip install -r requirements.txt
python models/train.py --data data/hr_data.csv
python models/explain.py
python models/score.py --output scored_employees.csv
```

## Key Features Used
- `tenure_days` — time since hire date
- `performance_rating` — last annual review score (1-5)
- `months_since_promotion` — time since last promotion
- `comp_ratio` — salary / midpoint of pay band
- `manager_span` — number of direct reports manager has
- `days_since_last_raise` — time since last compensation change
- `voluntary_transfers_12m` — internal role changes in last year
- `engagement_score` — latest engagement survey score

## Model Performance
| Metric | Score |
|---|---|
| AUC-ROC | 0.84 |
| Precision (high risk) | 0.79 |
| Recall (high risk) | 0.71 |
| F1 Score | 0.75 |
