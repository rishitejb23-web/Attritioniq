"""
AttritionIQ — Model Training
Trains an XGBoost classifier to predict 90-day voluntary attrition.
"""

import argparse
import json
import logging
import joblib
import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import (
    roc_auc_score, classification_report,
    precision_recall_curve, average_precision_score
)
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import xgboost as xgb

from features import load_hr_data, build_features, split_features_target

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

MODEL_PATH = Path("models/attrition_model.pkl")
METRICS_PATH = Path("models/metrics.json")


def train(data_path: str):
    log.info("Loading HR data...")
    df_raw = load_hr_data(data_path)

    log.info("Engineering features...")
    df, feature_cols = build_features(df_raw)
    X, y = split_features_target(df, feature_cols)

    log.info(f"Class distribution: {y.value_counts().to_dict()}")
    pos_weight = (y == 0).sum() / (y == 1).sum()
    log.info(f"scale_pos_weight = {pos_weight:.2f}")

    model = xgb.XGBClassifier(
        n_estimators=400,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=pos_weight,
        eval_metric="auc",
        use_label_encoder=False,
        random_state=42,
        n_jobs=-1
    )

    log.info("Running 5-fold cross-validation...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X, y, cv=cv, scoring="roc_auc", n_jobs=-1)
    log.info(f"CV AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

    log.info("Fitting final model on full dataset...")
    model.fit(X, y)

    y_prob = model.predict_proba(X)[:, 1]
    auc = roc_auc_score(y, y_prob)
    ap  = average_precision_score(y, y_prob)
    log.info(f"Train AUC: {auc:.4f}  |  Average Precision: {ap:.4f}")

    # Feature importance
    importance = dict(zip(feature_cols, model.feature_importances_))
    top_features = sorted(importance.items(), key=lambda x: x[1], reverse=True)
    log.info("Top 5 features by importance:")
    for feat, score in top_features[:5]:
        log.info(f"  {feat}: {score:.4f}")

    # Save model
    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump({"model": model, "feature_cols": feature_cols}, MODEL_PATH)
    log.info(f"Model saved to {MODEL_PATH}")

    metrics = {
        "cv_auc_mean": round(cv_scores.mean(), 4),
        "cv_auc_std":  round(cv_scores.std(), 4),
        "train_auc":   round(auc, 4),
        "avg_precision": round(ap, 4),
        "top_features": top_features[:10],
        "n_samples": len(X),
        "n_positive": int(y.sum()),
        "feature_cols": feature_cols
    }
    METRICS_PATH.write_text(json.dumps(metrics, indent=2))
    log.info(f"Metrics saved to {METRICS_PATH}")
    return model, feature_cols


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="Path to HR data CSV")
    args = parser.parse_args()
    train(args.data)
