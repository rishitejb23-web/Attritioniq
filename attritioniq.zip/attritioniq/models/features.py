"""
AttritionIQ — Feature Engineering
Builds model-ready features from raw HR / Workday HCM data.
"""

import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.preprocessing import LabelEncoder
import logging

log = logging.getLogger(__name__)


def load_hr_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["hire_date", "last_promotion_date",
                                         "last_raise_date", "termination_date",
                                         "snapshot_date"])
    log.info(f"Loaded {len(df):,} employee records")
    return df


def build_features(df: pd.DataFrame, snapshot_date: datetime = None) -> pd.DataFrame:
    """
    Engineer features for attrition prediction.
    snapshot_date: the reference date for calculating tenure etc.
    """
    snap = snapshot_date or datetime.today()
    df = df.copy()

    # ── Tenure ────────────────────────────────────────────────────────────────
    df["tenure_days"] = (snap - df["hire_date"]).dt.days
    df["tenure_years"] = df["tenure_days"] / 365.25

    # ── Promotion recency ─────────────────────────────────────────────────────
    df["months_since_promotion"] = (
        (snap - df["last_promotion_date"]).dt.days / 30.44
    ).clip(lower=0)

    # ── Compensation ──────────────────────────────────────────────────────────
    df["comp_ratio"] = (df["base_salary"] / df["pay_band_midpoint"]).clip(0.5, 2.0)
    df["days_since_last_raise"] = (snap - df["last_raise_date"]).dt.days

    # ── Manager span ──────────────────────────────────────────────────────────
    df["manager_span"] = df["manager_span"].fillna(df["manager_span"].median())

    # ── Engagement ────────────────────────────────────────────────────────────
    df["engagement_score"] = df["engagement_score"].fillna(
        df["engagement_score"].mean()
    )

    # ── Performance ───────────────────────────────────────────────────────────
    df["performance_rating"] = df["performance_rating"].fillna(3.0)
    df["performance_below_avg"] = (df["performance_rating"] < 3.0).astype(int)

    # ── Department encoding ───────────────────────────────────────────────────
    le = LabelEncoder()
    df["department_encoded"] = le.fit_transform(df["department"].fillna("Unknown"))
    df["level_encoded"]      = le.fit_transform(df["job_level"].fillna("IC"))

    # ── Target ───────────────────────────────────────────────────────────────
    if "termination_date" in df.columns:
        df["attrited_90d"] = (
            (df["termination_date"].notna()) &
            ((df["termination_date"] - snap).dt.days <= 90) &
            (df["termination_type"] == "Voluntary")
        ).astype(int)

    feature_cols = [
        "tenure_days", "tenure_years", "months_since_promotion",
        "comp_ratio", "days_since_last_raise", "manager_span",
        "engagement_score", "performance_rating", "performance_below_avg",
        "voluntary_transfers_12m", "department_encoded", "level_encoded"
    ]

    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing feature columns: {missing}")

    log.info(f"Built {len(feature_cols)} features for {len(df):,} employees")
    return df, feature_cols


def split_features_target(df: pd.DataFrame, feature_cols: list):
    X = df[feature_cols]
    y = df["attrited_90d"] if "attrited_90d" in df.columns else None
    return X, y
